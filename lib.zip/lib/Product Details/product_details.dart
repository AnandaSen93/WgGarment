import 'package:flutter/material.dart';
import 'package:flutter_platform_widgets/flutter_platform_widgets.dart';
import 'package:wg_garment/Config/colors.dart';
import 'package:wg_garment/Config/textstyle.dart';
import 'package:custom_rating_bar/custom_rating_bar.dart';
import 'dart:async';

class ProductDetailsView extends StatefulWidget {
  const ProductDetailsView({super.key});

  get pages => null;

  @override
  State<ProductDetailsView> createState() => _ProductDetailsViewState();
}

class _ProductDetailsViewState extends State<ProductDetailsView> {
  PageController pageController = PageController();
  int currentPageIndex = 0;
  late Timer _timer;

  var listForPageView = [
    "Description",
    "Highlights",
    "Material and Care",
    "Other Info"
  ];

  var list = [
    Image.asset(
      'assets/images/banner.png',
      fit: BoxFit.fill,
    ),
    Image.asset(
      'assets/images/banner.png',
      fit: BoxFit.fill,
    ),
    Image.asset(
      'assets/images/banner.png',
      fit: BoxFit.fill,
    ),
    Image.asset(
      'assets/images/banner.png',
      fit: BoxFit.fill,
    ),
    Image.asset(
      'assets/images/banner.png',
      fit: BoxFit.fill,
    ),
  ];

  @override
  void initState() {
    super.initState();
    pageController = PageController();
    // _startTimer();
  }

  @override
  void dispose() {
    _timer.cancel();
    pageController.dispose();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 2), (timer) {
      currentPageIndex = currentPageIndex + 1;
      if (currentPageIndex >= list.length) {
        currentPageIndex = 0;
      }
      // pageController.animateToPage(
      //   currentPageIndex,
      //   duration: Duration(milliseconds: 500),
      //   curve: Curves.easeIn,
      // );
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;
    return PlatformScaffold(
      body: SafeArea(
          child: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Product image slider
              Stack(children: [
                AspectRatio(
                  aspectRatio: 2,
                  child: Container(
                    color: Colors.transparent,
                    child: PageView(
                      controller: pageController,
                      onPageChanged: (int index) {
                        setState(() {
                          currentPageIndex = index;
                        });
                      },
                      children: list,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 10,
                  child: Row(
                    children: [
                      Container(
                        height: 40,
                        width: list.length * 20,
                        color: Colors.transparent,
                        child: ListView.builder(
                            itemCount: list.length,
                            scrollDirection: Axis.horizontal,
                            itemBuilder: (context, index) {
                              return Container(
                                padding: EdgeInsets.only(left: 2, right: 2),
                                child: Icon(
                                  Icons.circle,
                                  size: 10,
                                  color: index == currentPageIndex
                                      ? Colors.red
                                      : Colors.grey,
                                ),
                              );
                            }),
                      ),
                    ],
                  ),
                )
              ]),
              // Name and Price
              Container(
                padding: EdgeInsets.only(left: 10, right: 10),
                height: 50,
                child: Row(
                  children: [
                    Expanded(
                        child: Text(
                      "Tristique Mauris Sollicitudin",
                      style: textStyleForProductName,
                    )),
                    AspectRatio(
                      aspectRatio: 1,
                      child: Container(
                        color: Colors.transparent,
                        alignment: Alignment.center,
                        child: Text(
                          "599 SEK",
                          style: textStyleForMainPrice,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  ],
                ),
              ),
              // ratting and quantity
              Container(
                height: 40,
                padding: EdgeInsets.only(left: 10, right: 10),
                color: Colors.transparent,
                child: Row(
                  children: [
                    RatingBar.readOnly(
                      filledIcon: Icons.star,
                      emptyIcon: Icons.star_border,
                      initialRating: 4,
                      maxRating: 5,
                      size: 20,
                    ),
                    SizedBox(height: 10),
                    Text(
                      "(15)",
                      style: textStyleForMainProductDescription,
                    ),
                    Spacer(),
                    AspectRatio(
                      aspectRatio: 3,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.transparent,
                          border: Border.all(
                            color: Colors.black,
                            width: 1.0,
                          ),
                        ),
                        child: Row(
                          children: [
                            AspectRatio(
                              aspectRatio: 1,
                              child: IconButton(
                                  onPressed: () {}, icon: Icon(Icons.remove)),
                            ),
                            Spacer(),
                            Text(
                              "1",
                              style: textStyleForCategorytName,
                            ),
                            Spacer(),
                            AspectRatio(
                              aspectRatio: 1,
                              child: IconButton(
                                  onPressed: () {}, icon: Icon(Icons.add)),
                            )
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 10),
              // pageview
              Container(
                  height: 50,
                  child: ListView.builder(
                      itemCount: listForPageView.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return Container(
                          padding: EdgeInsets.all(5),
                          color: Colors.red,
                          child: Column(
                            children: [
                              Text(
                                listForPageView[index],
                                style: textStyleForCategorytName,
                              ),
                              SizedBox(height: 5),
                              Flexible(
                                child: Container(
                                  color: Colors.yellow,
                                  height: 2,
                                  width:double.infinity
                                ))
                             
                            ],
                          ),
                        );
                      }))
            ],
          ),
        ),
      )),
    );
  }
}
