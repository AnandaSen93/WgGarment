

import 'package:flutter/material.dart';

const pinkcolor = Color(0xFFED008C);
const lightgraykcolor = Color(0xFFF5F5F5);

const productbackgroundcolor = Color(0xFFE9E6E4);










