import 'package:flutter/material.dart';
import 'package:wg_garment/Home/home.dart';
import 'package:wg_garment/Login/login.dart';
import 'package:wg_garment/Menu/menu.dart';
import 'package:wg_garment/Product%20Details/product_details.dart';
import 'package:wg_garment/Signup/signup.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: 'ProductDetailsView',
      routes: {
        'HomeView': (context) => const HomeView(),
        'MenuView': (context) => const MenuView(),
        'LoginView': (context) => const LoginView(),
        'SignupView': (context) => const SignupView(),
        'ProductDetailsView': (context) => const ProductDetailsView(),
        
      },
    );
  }
}
